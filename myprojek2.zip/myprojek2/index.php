<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KAI KRD BANDUNG BARAT - Beranda</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <!-- My Css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- My Font -->
    <link rel="stylesheet" href="css/font.css">
</head>

<body style="background-color: #000;">

    <!-- Navbar -->
    <nav class="my-nav fixed-top">
        <a class="nav-brand f1-nav-brand fst-italic" href="#">
            <span>KAI</span>
            <span class="r">KRD</span>
            <span>BANDUNG</span>
            <span class="r">BARAT</span>
        </a>
        <div class="fw-bold mt-2">
            <a class="nav-link-btn" href="daftar.php">Daftar</a></li>
        </div>
    </nav>

    <!-- login -->
    <div class="login">
        <p class="text-center f1-opening text-white">LOGIN UNTUK MASUK</p>
        <?php
        session_start();
        require_once "koneksi.php";

        if (isset($_POST["login"])) {
            $input_username = $_POST["username"];
            $input_password = $_POST["password"];

            $query = "SELECT * FROM akun WHERE username = '$input_username' AND password = '$input_password'";
            $result = $koneksi->query($query);
            $query2 = "SELECT * FROM akun_admin WHERE username = '$input_username' AND password = '$input_password'";
            $result2 = $koneksi->query($query2);

            if ($result->num_rows > 0) {
                $_SESSION["username"] = $input_username;
                header("Location: beranda.php");
            } else {
                if ($result2->num_rows > 0) {
                    $_SESSION["username"] = $input_username;
                    header("Location: beranda-admin.php");
                }
            }
        }
        ?>

        <form action="" method="post" class="area">
            <div class="mb-3">
                <label for="username" class="form-label fw-semibold text-white">USERNAME :</label>
                <input type="text" class="form-control" id="username" name="username">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label fw-semibold text-white">PASSWORD :</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
            <div class="text-center">
                <button type="submit" name="login" class="log-btn f1-b-btn mt-4">LOGIN</button>
            </div>
        </form>
    </div>

    <!-- Footer -->
    <div class="my-foot">
        <div class="text-center">
            <div class="foot-icon-area d-flex justify-content-center mb-5 mt-4">
                <a class="foot-link me-3" href="https://www.instagram.com/ivana.azmi.90/">
                    <img class="foot-icon" src="assets/icon/instagram.png" alt="">
                    <p class="mt-2 f1-foot-link">Instagran</p>
                </a>
                <a class="foot-link" href="https://mail.google.com/">
                    <img class="foot-icon mx-5" src="assets/icon/gmail.png" alt="">
                    <p class="mt-2 f1-foot-link">Gmail</p>
                </a>
                <a class="foot-link ms-3"
                    href="https://www.tiktok.com/@bukansiapaasiapaa?is_from_webapp=1&sender_device=pc">
                    <img class="foot-icon" src="assets/icon/Tiktok.png" alt="">
                    <p class="mt-2 f1-foot-link">Tiktok</p>
                </a>
            </div>
            <hr style="border-color: #fff;">
            <p class="pb-3" style="opacity: 50%;">&copy;2023 PT KERETA API INDONESIA (PERSERO)</p>
        </div>
    </div>

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>

</html>