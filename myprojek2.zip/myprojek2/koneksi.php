<?php

$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "db_tiketkai";

$koneksi = new mysqli($hostname, $username, $password, $dbname);

?>