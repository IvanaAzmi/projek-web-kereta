<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sesi = $_POST["sesi"];
    $tanggal = $_POST["tanggal"];
    $dewasa = $_POST["dewasa"];
    $bayi = $_POST["bayi"];
    $username = $_SESSION["username"];

    $sql = "INSERT INTO tb_tiket (sesi, tanggal, dewasa, bayi, id_user) VALUES ('$sesi', '$tanggal', '$dewasa', '$bayi', '$username')";
}

if ($koneksi->query($sql) === TRUE) {
    $randomNumber = rand(10000000000, 100000000000);
    $sqlRnum = "INSERT INTO tb_resi (number) VALUES ('$randomNumber')";
    $koneksi->query($sqlRnum);
    header("Location: bayar.php");
} else {
    echo "Error :" . $sql . "<br>" . mysqli_error($koneksi);
}
?>