<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $email = $_POST["email"];
    $pesan = $_POST["pesan"];
    $username = $_SESSION["username"];

    $sql = "INSERT INTO kontak (nama, email, pesan, username) VALUES ('$nama', '$email', '$pesan', '$username')";
}

if ($koneksi->query($sql) === TRUE) {
    header("Location: kontak.php");
} else {
    echo "Error : Pesan tidak terkirim";
}
?>