<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $alamat = $_POST["alamat"];
    $notelp = $_POST["notelp"];
    $nik = $_POST["nik"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "INSERT INTO akun (nama, alamat, notelp, nik, username, password) VALUES ('$nama', '$alamat', '$notelp', '$nik', '$username', '$password')";
}

if ($koneksi->query($sql) === TRUE) {
    header("Location: index.php");
} else {
    echo "Error :" . $sql . "<br>" . mysqli_error($koneksi);
}

?>