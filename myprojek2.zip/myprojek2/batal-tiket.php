<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KAI KRD BANDUNG BARAT - Beranda</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <!-- My Css -->
    <link rel="stylesheet" href="css/batal-tiket.css">
    <!-- My Font -->
    <link rel="stylesheet" href="css/font.css">
</head>

<body style="background-color: #000;">

    <!-- Navbar -->
    <nav class="my-nav fixed-top">
        <a class="nav-brand f1-nav-brand fst-italic" href="#">
            <span>KAI</span>
            <span class="r">KRD</span>
            <span>BANDUNG</span>
            <span class="r">BARAT</span>
        </a>
        <div class="fw-bold mt-2">
            <a class="nav-link" href="beranda-admin.php">BERANDA </a>
            <a class="nav-link-active mx-4" href="tiket-admin.php">KONFIRMASI TIKET</a>
            <a class="nav-link" href="kontak-admin.php">LAPORAN</a>
    </nav>

    <!-- Pesan -->
    <?php
    include 'koneksi.php';

    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        // Ambil data berdasarkan ID
        $sql = "SELECT id, sesi, tanggal, dewasa, bayi, id_user FROM tb_tiket WHERE id = $id";
        $result = $koneksi->query($sql);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $sesi = $row['sesi'];
            $tanggal = $row['tanggal'];
            $dewasa = $row['dewasa'];
            $bayi = $row['bayi'];
            $user = $row['id_user'];
        } else {
            echo "Data tidak ditemukan.";
            exit();
        }
    } else {
        echo "ID tidak diberikan.";
        exit();
    }

    // Jika data diperbarui
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $newStatus = "GAGAL / DIBATALKAN";

        $sql_update = "UPDATE tb_tiket SET status = '$newStatus' WHERE id = $id";
        if ($koneksi->query($sql_update) === TRUE) {
            header("Location: tiket-admin.php");
        } else {
            echo "Error: Data tidak berhasil diperbarui";
        }
    }
    ?>

    <div class="pesan">
        <p class="text-center f1-opening text-white">KONFIRMASI STATUS <span class="r">GAGAL / DIBATALKAN</span></p>
        <form method="post" class="area">
            <div class="text-center mb-3" style="width:30%; margin-left: 290px;">
                <label for="tiba" class="form-label fw-semibold text-white">ATAS NAMA</label>
                <input type="text" class="form-control text-center" id="tiba" name="tiba" value="<?php echo $user; ?>"
                    required>
            </div>
            <div class="text-center d-flex">
                <div class="mb-3 me-2">
                    <label for="asal" class="form-label fw-semibold text-white">SESI</label>
                    <input type="text" class="form-control text-center" id="asal" name="asal"
                        value="<?php echo $sesi; ?>" required>
                </div>
                <div class="mb-3 mx-2">
                    <label for="tujuan" class="form-label fw-semibold text-white">TANGGAL</label>
                    <input type="text" class="form-control text-center" id="tujuan" name="tujuan"
                        value="<?php echo $tanggal; ?>" required>
                </div>
                <div class="mb-3 mx-2">
                    <label for="kd" class="form-label fw-semibold text-white">DEWASA</label>
                    <input type="text" class="form-control text-center" id="kd" name="kd" value="<?php echo $dewasa; ?>"
                        required>
                </div>
                <div class="mb-3 ms-2">
                    <label for="kb" class="form-label fw-semibold text-white">BAYI <3< /label>
                            <input type="text" class="form-control text-center" id="kb" name="kb"
                                value="<?php echo $bayi; ?>" required>
                </div>
            </div>
            <div class="text-center mt-5">
                <input type="submit" value="KONFIRMASI" class="jd-btn f1-b-btn"></input>
            </div>
        </form>
    </div>

    <!-- Footer -->
    <div class="my-foot">
        <div class="text-center">
            <div class="foot-icon-area d-flex justify-content-center mb-5 mt-4">
                <a class="foot-link me-3" href="https://www.instagram.com/ivana.azmi.90/">
                    <img class="foot-icon" src="assets/icon/instagram.png" alt="">
                    <p class="mt-2 f1-foot-link">Instagran</p>
                </a>
                <a class="foot-link" href="https://mail.google.com/">
                    <img class="foot-icon mx-5" src="assets/icon/gmail.png" alt="">
                    <p class="mt-2 f1-foot-link">Gmail</p>
                </a>
                <a class="foot-link ms-3"
                    href="https://www.tiktok.com/@bukansiapaasiapaa?is_from_webapp=1&sender_device=pc">
                    <img class="foot-icon" src="assets/icon/Tiktok.png" alt="">
                    <p class="mt-2 f1-foot-link">Tiktok</p>
                </a>
            </div>
            <hr style="border-color: #fff;">
            <p class="pb-3" style="opacity: 50%;">&copy;2023 PT KERETA API INDONESIA (PERSERO)</p>
        </div>
    </div>

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>

</html>