<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KAI KRD BANDUNG BARAT - Beranda</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <!-- My Css -->
    <link rel="stylesheet" href="css/kontak-admin.css">
    <!-- My Font -->
    <link rel="stylesheet" href="css/font.css">
</head>

<body style="background-color: #000;">

    <!-- Navbar -->
    <nav class="my-nav fixed-top">
        <a class="nav-brand f1-nav-brand fst-italic" href="#">
            <span>KAI</span>
            <span class="r">KRD</span>
            <span>BANDUNG</span>
            <span class="r">BARAT</span>
        </a>
        <div class="fw-bold mt-2">
            <a class="nav-link mx-4" href="beranda-admin.php">BERANDA </a>
            <a class="nav-link" href="tiket-admin.php">KONFIRMASI TIKET </a>
            <a class="nav-link-active mx-4" href="kontak-admin.php">LAPORAN</a>
            <a class="nav-link-btn" href="index.php">Keluar <img style="margin-bottom: 1px;" width="15px" height="15px"
                    src="assets/icon/keluar.png" alt=""></a>
        </div>
    </nav>

    <!-- Opening -->
    <div class="opening">
        <div class="opn-text-area text-center">
            <p class="f1-opening p mb-0">TAMPILAN KELUHAN USER</p>
            <p class="p">ANDA PUNYA KONTROL PENUH ATAS WEBSITE INI <span class="r">HARAP GUNAKAN DENGAN BIJAK!</span>
            </p>
        </div>
        <hr style="border-color: #fff; opacity: 100%;">
    </div>

    <!-- Search Bar -->
    <div class="container mt-5">
        <form id="searchForm">
            <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Search..." id="searchInput" name="search">
                <button class="btn btn-outline-secondary" type="submit">Search</button>
            </div>
        </form>
    </div>

    <!-- Jadwal -->
    <div class="jadwal text-center">
        <p class="f1-subhead text-white mb-5">DATA DATA LAPORAN USER</p>
        <table class="table" style="border: transparent;">
            <tr class="f1-head-tab">
                <th style="background-color: #ff0000; color: #fff;">ID</th>
                <th style="background-color: #ff0000; color: #fff;">NAMA</th>
                <th style="background-color: #ff0000; color: #fff;">EMAIL</th>
                <th style="background-color: #ff0000; color: #fff;">PESAN</th>
                <th style="background-color: #ff0000; color: #fff;">AKUN</th>
            </tr>

            <?php
            include 'koneksi.php';
            // Check if the search parameter is set
            $search = isset($_GET['search']) ? $_GET['search'] : '';
            $query = "SELECT * FROM kontak WHERE nama LIKE '%$search%' OR email LIKE '%$search%' OR pesan LIKE '%$search%' OR username LIKE '%$search%'";
            $result = $koneksi->query($query);
            ?>

            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["id"]; ?>
                    </td>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["nama"]; ?>
                    </td>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["email"]; ?>
                    </td>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["pesan"]; ?>
                    </td>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["username"]; ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>

    <!-- Footer -->
    <div class="my-foot">
        <div class="text-center">
            <div class="foot-icon-area d-flex justify-content-center mb-5 mt-4">
                <a class="foot-link me-3" href="https://www.instagram.com/ivana.azmi.90/">
                    <img class="foot-icon" src="assets/icon/instagram.png" alt="">
                    <p class="mt-2 f1-foot-link">Instagran</p>
                </a>
                <a class="foot-link" href="https://mail.google.com/">
                    <img class="foot-icon mx-5" src="assets/icon/gmail.png" alt="">
                    <p class="mt-2 f1-foot-link">Gmail</p>
                </a>
                <a class="foot-link ms-3"
                    href="https://www.tiktok.com/@bukansiapaasiapaa?is_from_webapp=1&sender_device=pc">
                    <img class="foot-icon" src="assets/icon/Tiktok.png" alt="">
                    <p class="mt-2 f1-foot-link">Tiktok</p>
                </a>
            </div>
            <hr style="border-color: #fff;">
            <p class="pb-3" style="opacity: 50%;">&copy;2023 PT KERETA API INDONESIA (PERSERO)</p>
        </div>
    </div>

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>

    <!-- Search Script -->
    <script>
        document.getElementById('searchForm').addEventListener('submit', function (e) {
            e.preventDefault();
            var searchQuery = document.getElementById('searchInput').value;
            window.location.href = 'kontak-admin.php?search=' + searchQuery;
        });
    </script>
</body>

</html>