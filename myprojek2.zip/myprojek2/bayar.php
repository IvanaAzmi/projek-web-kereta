<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KAI KRD BANDUNG BARAT - Beranda</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <!-- My Css -->
    <link rel="stylesheet" href="css/byr.css">
    <!-- My Font -->
    <link rel="stylesheet" href="css/font.css">
</head>

<body style="background-color: #000;">

    <!-- Navbar -->
    <nav class="my-nav fixed-top">
        <a class="nav-brand f1-nav-brand fst-italic" href="#">
            <span>KAI</span>
            <span class="r">KRD</span>
            <span>BANDUNG</span>
            <span class="r">BARAT</span>
        </a>
        <div class="fw-bold mt-2">
            <a class="nav-link" href="beranda.php">BERANDA </a>
            <a class="nav-link mx-4" href="tiket.php">PESAN TIKET </a>
            <a class="nav-link-active" href="bayar.php">BAYAR TIKET</a>
            <a class="nav-link mx-4" href="kontak.php">KONTAK</a>
            <a class="nav-link-btn" href="index.php">Keluar <img style="margin-bottom: 1px;" width="15px" height="15px"
                    src="assets/icon/keluar.png" alt=""></a>
        </div>
    </nav>

    <!-- Resi -->
    <div class="resi">
        <p class="text-center f1-opening text-white">PERGI KE STASIUN UNTUK BAYAR</p>
        <div class="area fw-bold text-white">
            <?php
            include 'koneksi.php';
            $sqlRnum = "SELECT number FROM tb_resi ORDER BY id DESC LIMIT 1";
            $result = $koneksi->query($sqlRnum);
            $randomNumber = $result->fetch_assoc()['number'];

            $sqlData = "SELECT * FROM tb_tiket ORDER BY id DESC LIMIT 1";
            $res = $koneksi->query($sqlData);
            $data = $res->fetch_assoc();
            ?>
            <p>NOMOR TIKET :
                <span class="fw-normal opacity-50">
                    <?php echo $randomNumber; ?>
                </span>
            </p>
            <p>TANGGAL :
                <span class="fw-normal opacity-50">
                    <?php echo $data['tanggal']; ?>
                </span>
            </p>
            <p>SESI :
                <span class="fw-normal opacity-50">
                    <?php echo $data['sesi']; ?>
                </span>
            </p>
            <p>JUMLAH TIKET :
                <span class="fw-normal opacity-50">
                    <?php echo $data['dewasa'] . " DEWASA" . " - " . $data['bayi'] . " BAYI <3"; ?>
                </span>
            </p>
            <p>STATUS PEMBAYARAN :
                <span class="fw-normal" style="color : #fff">
                    <?php echo $data['status']; ?>
                </span>
            </p>
        </div>
    </div>

    <!-- Footer -->
    <div class="my-foot">
        <div class="text-center">
            <div class="foot-icon-area d-flex justify-content-center mb-5 mt-4">
                <a class="foot-link me-3" href="https://www.instagram.com/ivana.azmi.90/">
                    <img class="foot-icon" src="assets/icon/instagram.png" alt="">
                    <p class="mt-2 f1-foot-link">Instagran</p>
                </a>
                <a class="foot-link" href="https://mail.google.com/">
                    <img class="foot-icon mx-5" src="assets/icon/gmail.png" alt="">
                    <p class="mt-2 f1-foot-link">Gmail</p>
                </a>
                <a class="foot-link ms-3"
                    href="https://www.tiktok.com/@bukansiapaasiapaa?is_from_webapp=1&sender_device=pc">
                    <img class="foot-icon" src="assets/icon/Tiktok.png" alt="">
                    <p class="mt-2 f1-foot-link">Tiktok</p>
                </a>
            </div>
            <hr style="border-color: #fff;">
            <p class="pb-3" style="opacity: 50%;">&copy;2023 PT KERETA API INDONESIA (PERSERO)</p>
        </div>
    </div>

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>

</html>