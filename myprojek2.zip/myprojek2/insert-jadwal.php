<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $asal = $_POST["asal"];
    $tujuan = $_POST["tujuan"];
    $kd = $_POST["kd"];
    $kb = $_POST["kb"];
    $tiba = $_POST["tiba"];

    $sql = "INSERT INTO jadwal (asal, tujuan, kd, kb,tiba) VALUES ('$asal', '$tujuan', '$kd', '$kb','$tiba')";
}

if ($koneksi->query($sql) === TRUE) {
    header("Location: beranda-admin.php");
} else {
    echo "Error : Pesan tidak terkirim";
}
?>