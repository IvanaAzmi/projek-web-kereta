<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KAI KRD BANDUNG BARAT - Beranda</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <!-- My Css -->
    <link rel="stylesheet" href="css/kon.css">
    <!-- My Font -->
    <link rel="stylesheet" href="css/font.css">
</head>

<body style="background-color: #000;">

    <!-- Navbar -->
    <nav class="my-nav fixed-top">
        <a class="nav-brand f1-nav-brand fst-italic" href="#">
            <span>KAI</span>
            <span class="r">KRD</span>
            <span>BANDUNG</span>
            <span class="r">BARAT</span>
        </a>
        <div class="fw-bold mt-2">
            <a class="nav-link" href="beranda.php">BERANDA </a>
            <a class="nav-link mx-4" href="tiket.php">PESAN TIKET</a>
            <a class="nav-link" href="bayar.php">BAYAR TIKET</a>
            <a class="nav-link-active mx-4" href="kontak.php">KONTAK</a>
            <a class="nav-link-btn" href="index.php">Keluar <img style="margin-bottom: 1px;" width="15px" height="15px"
                    src="assets/icon/keluar.png" alt=""></a>
        </div>
    </nav>

    <!-- Pesan -->

    <div class="pesan">
        <p class="text-center f1-opening text-white">TINGGALKAN PESAN DISINI</p>
        <form action="insert-kontak.php" method="post" class="area">
            <div class="mb-3">
                <label for="nama" class="form-label fw-semibold text-white">NAMA</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label fw-semibold text-white">EMAIL</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="pesan" class="form-label fw-semibold text-white">PESAN</label>
                <textarea type="text" class="form-control" id="pesan" name="pesan" rows="3" required></textarea>
            </div>
            <div class="text-center mt-5">
                <button type="submit" name="kirimpesan" class="jd-btn f1-b-btn">KIRIM PESAN</button>
            </div>
        </form>
    </div>

    <!-- Footer -->
    <div class="my-foot">
        <div class="text-center">
            <div class="foot-icon-area d-flex justify-content-center mb-5 mt-4">
                <a class="foot-link me-3" href="https://www.instagram.com/ivana.azmi.90/">
                    <img class="foot-icon" src="assets/icon/instagram.png" alt="">
                    <p class="mt-2 f1-foot-link">Instagran</p>
                </a>
                <a class="foot-link" href="https://mail.google.com/">
                    <img class="foot-icon mx-5" src="assets/icon/gmail.png" alt="">
                    <p class="mt-2 f1-foot-link">Gmail</p>
                </a>
                <a class="foot-link ms-3"
                    href="https://www.tiktok.com/@bukansiapaasiapaa?is_from_webapp=1&sender_device=pc">
                    <img class="foot-icon" src="assets/icon/Tiktok.png" alt="">
                    <p class="mt-2 f1-foot-link">Tiktok</p>
                </a>
            </div>
            <hr style="border-color: #fff;">
            <p class="pb-3" style="opacity: 50%;">&copy;2023 PT KERETA API INDONESIA (PERSERO)</p>
        </div>
    </div>

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>

</html>