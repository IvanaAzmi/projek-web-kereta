<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KAI KRD BANDUNG BARAT - Beranda</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <!-- My Css -->
    <link rel="stylesheet" href="css/beranda.css">
    <!-- My Font -->
    <link rel="stylesheet" href="css/font.css">
</head>

<body style="background-color: #000;">

    <!-- Navbar -->
    <nav class="my-nav fixed-top">
        <a class="nav-brand f1-nav-brand fst-italic" href="#">
            <span>KAI</span>
            <span class="r">KRD</span>
            <span>BANDUNG</span>
            <span class="r">BARAT</span>
        </a>
        <div class="fw-bold mt-2">
            <a class="nav-link-active" href="beranda.php">BERANDA </a>
            <a class="nav-link mx-4" href="tiket.php">PESAN TIKET </a>
            <a class="nav-link" href="bayar.php">BAYAR TIKET</a>
            <a class="nav-link mx-4" href="kontak.php">KONTAK</a>
            <a class="nav-link-btn" href="index.php">Keluar <img style="margin-bottom: 1px;" width="15px" height="15px"
                    src="assets/icon/keluar.png" alt=""></a>
        </div>
    </nav>

    <!-- Opening -->
    <div class="opening">
        <div class="opn-text-area text-start">
            <p class="f1-opening p mb-0">SELAMAT DATANG DI WEBSITE</p>
            <p class="f1-opening p">KAI<span class="r"> KRD</span> BANDUNG<span class="r"> BARAT</span></p>
            <p class="fw-semibold ptx fs-5">KAI KRD BANDUNG BARAT adalah sebuah website penjualan tiket kereta api yang
                bertujuan agar mempermudah
                dalam pemesanan tiket kereta api yang ada di daerah Bandung Barat. Website ini rilis pada tanggal 28
                Januari 2023.</p>
        </div>
        <hr style="border-color: #fff; opacity: 100%;">
    </div>

    <!-- Jadwal -->
    <div class="jadwal text-center">
        <p class="f1-subhead text-white mb-5">JADWAL KEBERANGKATAN KERETA API</p>
        <table class="table" style="border: transparent;">
            <tr class="f1-head-tab">
                <th style="background-color: #ff0000; color: #fff;">ASAL</th>
                <th style="background-color: #ff0000; color: #fff;">TUJUAN</th>
                <th style="background-color: #ff0000; color: #fff;">KD</th>
                <th style="background-color: #ff0000; color: #fff;">KB</th>
                <th style="background-color: #ff0000; color: #fff;">TIBA DI TUJUAN</th>
            </tr>

            <?php
            include 'koneksi.php';
            $query = "SELECT * FROM jadwal";
            $result = $koneksi->query($query);
            ?>

            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["asal"]; ?>
                    </td>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["tujuan"]; ?>
                    </td>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["kd"]; ?>
                    </td>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["kb"]; ?>
                    </td>
                    <td style="background-color: #000; color: #fff;">
                        <?php echo $row["tiba"]; ?>
                    </td>
                </tr>
            <?php } ?>

        </table>
        <div class="mt-5">
            <a class="jd-btn f1-b-btn" href="tiket.php">PESAN TIKET SEKARANG</a>
        </div>
    </div>

    <!-- Footer -->
    <div class="my-foot">
        <div class="text-center">
            <div class="foot-icon-area d-flex justify-content-center mb-5 mt-4">
                <a class="foot-link me-3" href="https://www.instagram.com/ivana.azmi.90/">
                    <img class="foot-icon" src="assets/icon/instagram.png" alt="">
                    <p class="mt-2 f1-foot-link">Instagran</p>
                </a>
                <a class="foot-link" href="https://mail.google.com/">
                    <img class="foot-icon mx-5" src="assets/icon/gmail.png" alt="">
                    <p class="mt-2 f1-foot-link">Gmail</p>
                </a>
                <a class="foot-link ms-3"
                    href="https://www.tiktok.com/@bukansiapaasiapaa?is_from_webapp=1&sender_device=pc">
                    <img class="foot-icon" src="assets/icon/Tiktok.png" alt="">
                    <p class="mt-2 f1-foot-link">Tiktok</p>
                </a>
            </div>
            <hr style="border-color: #fff;">
            <p class="pb-3" style="opacity: 50%;">&copy;2023 PT KERETA API INDONESIA (PERSERO)</p>
        </div>
    </div>

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>

</html>